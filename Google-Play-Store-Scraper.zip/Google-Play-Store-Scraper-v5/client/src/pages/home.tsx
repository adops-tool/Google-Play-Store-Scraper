import { useState } from "react";
import { useScrapedApps, useScrapeUrl, useClearApps } from "@/hooks/use-scraped-apps";
import { ResultsTable } from "@/components/results-table";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Download, Play, Trash2, Copy, Check } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [input, setInput] = useState("");
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { data: apps = [], isLoading: isLoadingApps } = useScrapedApps();
  const scrapeMutation = useScrapeUrl();
  const clearMutation = useClearApps();
  const { toast } = useToast();

  const handleProcess = async () => {
    const urls = input
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0);

    if (urls.length === 0) {
      toast({
        variant: "destructive",
        title: "Empty input",
        description: "Please enter at least one URL",
      });
      return;
    }

    setProcessing(true);
    setProgress(0);
    
    let completed = 0;
    
    // Process sequentially to avoid rate limiting
    for (const url of urls) {
      try {
        await scrapeMutation.mutateAsync(url);
      } catch (e) {
        console.error(`Failed to scrape ${url}`, e);
        // Toast is handled in mutation hook
      } finally {
        completed++;
        setProgress((completed / urls.length) * 100);
      }
    }

    setProcessing(false);
    setInput("");
    toast({
      title: "Batch complete",
      description: `Processed ${urls.length} URLs`,
    });
  };

  const handleExport = () => {
    if (apps.length === 0) return;
    
    const exportData = apps.map(app => ({
      studio_name: app.studioName,
      game_title: app.gameTitle,
      support_email: app.supportEmail,
      developer_email: app.developerEmail,
      website_url: app.websiteUrl,
      original_url: app.originalUrl,
      download_count: app.downloadCount,
    }));

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `play-store-scrape-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Exported",
      description: "Data downloaded as JSON",
    });
  };

  const handleCopyToClipboard = () => {
    if (apps.length === 0) return;

    const exportData = apps.map(app => ({
      studio_name: app.studioName,
      game_title: app.gameTitle,
      support_email: app.supportEmail,
      developer_email: app.developerEmail,
      website_url: app.websiteUrl,
      original_url: app.originalUrl,
      download_count: app.downloadCount,
    }));

    navigator.clipboard.writeText(JSON.stringify(exportData, null, 2));
    
    toast({
      title: "Copied",
      description: "Data copied to clipboard",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/50 p-6 md:p-12">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60 pb-2">
              Play Store Scraper
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Extract developer contact information directly from Google Play Store listings.
            </p>
          </motion.div>
        </div>

        {/* Input Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="p-1 shadow-lg bg-white/50 backdrop-blur-sm border-primary/10">
            <div className="bg-background rounded-xl p-6 md:p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-foreground uppercase tracking-wider">
                  Target URLs
                </label>
                <Textarea
                  placeholder="https://play.google.com/store/apps/details?id=..."
                  className="min-h-[160px] font-mono text-sm resize-y border-border focus:border-primary/50 focus:ring-4 focus:ring-primary/5 transition-all rounded-xl p-4 leading-relaxed"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={processing}
                />
                <p className="text-xs text-muted-foreground flex justify-between">
                  <span>Enter one URL per line</span>
                  <span>{input.split('\n').filter(l => l.trim()).length} URLs detected</span>
                </p>
              </div>

              <div className="flex items-center justify-end">
                <Button 
                  onClick={handleProcess} 
                  disabled={processing || !input.trim()}
                  className="h-12 px-8 rounded-xl font-semibold bg-primary hover:bg-primary/90 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0"
                >
                  {processing ? (
                    <>
                      <LoadingSpinner className="mr-2 text-white" />
                      Processing {Math.round(progress)}%
                    </>
                  ) : (
                    <>
                      <Play className="mr-2 w-4 h-4 fill-current" />
                      Start Scraping
                    </>
                  )}
                </Button>
              </div>
              
              {/* Progress bar */}
              {processing && (
                <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-primary"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ type: "spring", stiffness: 50 }}
                  />
                </div>
              )}
            </div>
          </Card>
        </motion.div>

        {/* Results Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-6"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold">Extracted Data</h2>
              <p className="text-muted-foreground text-sm">
                {apps.length} records found
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                onClick={() => clearMutation.mutate()}
                disabled={apps.length === 0 || processing}
                className="text-destructive hover:text-destructive hover:bg-destructive/5 border-destructive/20 hover:border-destructive/30"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
              <div className="h-6 w-px bg-border hidden md:block" />
              <Button
                variant="outline"
                onClick={handleCopyToClipboard}
                disabled={apps.length === 0}
                className="hover:bg-primary/5 hover:text-primary hover:border-primary/20"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy JSON
              </Button>
              <Button
                onClick={handleExport}
                disabled={apps.length === 0}
                className="bg-foreground text-background hover:bg-foreground/90"
              >
                <Download className="w-4 h-4 mr-2" />
                Save Array
              </Button>
            </div>
          </div>

          <ResultsTable data={apps} isLoading={isLoadingApps} />
        </motion.div>
      </div>
    </div>
  );
}
