import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type ScrapeRequest, type InsertScrapedApp } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useScrapedApps() {
  return useQuery({
    queryKey: [api.apps.list.path],
    queryFn: async () => {
      const res = await fetch(api.apps.list.path);
      if (!res.ok) throw new Error("Failed to fetch apps");
      return api.apps.list.responses[200].parse(await res.json());
    },
  });
}

export function useScrapeUrl() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (url: string) => {
      // 1. Scrape the data
      const scrapeRes = await fetch(api.scrape.path, {
        method: api.scrape.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url } as ScrapeRequest),
      });

      if (!scrapeRes.ok) {
        const error = await scrapeRes.json().catch(() => ({}));
        throw new Error(error.message || "Failed to scrape URL");
      }
      
      const scrapedData = api.scrape.responses[200].parse(await scrapeRes.json());

      // 2. Save to database immediately
      const saveRes = await fetch(api.apps.create.path, {
        method: api.apps.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(scrapedData),
      });

      if (!saveRes.ok) throw new Error("Failed to save scraped data");
      return api.apps.create.responses[201].parse(await saveRes.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.apps.list.path] });
      toast({
        title: "Success",
        description: `Processed ${data.studioName || "app"} successfully`,
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    },
  });
}

export function useClearApps() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.apps.clear.path, {
        method: api.apps.clear.method,
      });
      if (!res.ok) throw new Error("Failed to clear apps");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.apps.list.path] });
      toast({
        title: "Cleared",
        description: "All scraped data has been removed",
      });
    },
  });
}
