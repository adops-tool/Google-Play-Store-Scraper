import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const scrapedApps = pgTable("scraped_apps", {
  id: serial("id").primaryKey(),
  originalUrl: text("original_url").notNull(),
  studioName: text("studio_name"),
  gameTitle: text("game_title"),
  supportEmail: text("support_email"),
  developerEmail: text("developer_email"),
  websiteUrl: text("website_url"),
  downloadCount: text("download_count"),
});

export const insertScrapedAppSchema = createInsertSchema(scrapedApps).omit({ id: true });

export type ScrapedApp = typeof scrapedApps.$inferSelect;
export type InsertScrapedApp = z.infer<typeof insertScrapedAppSchema>;

export const scrapeRequestSchema = z.object({
  url: z.string().url(),
});

export type ScrapeRequest = z.infer<typeof scrapeRequestSchema>;
