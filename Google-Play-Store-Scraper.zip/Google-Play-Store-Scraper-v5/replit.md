# Google Play Store Scraper

## Overview

A web application for scraping developer contact information from Google Play Store app listings. Users can input multiple Google Play URLs, and the system extracts studio names, support emails, website URLs, and download counts. Results are persisted to a database and can be exported as JSON.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, built using Vite
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens (CSS variables for theming)
- **Animations**: Framer Motion for smooth UI transitions

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Pattern**: RESTful endpoints defined in shared routes module
- **Web Scraping**: Cheerio for parsing Google Play Store HTML pages
- **Reliability**: Exponential backoff retry logic for scraping operations

### Data Storage
- **Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM with Zod schema validation
- **Schema**: Single `scraped_apps` table storing URL, studio name, email, website, and download count

### API Structure
- `POST /api/scrape` - Scrapes a single Google Play URL and returns metadata
- `GET /api/apps` - Lists all saved scraped apps
- `POST /api/apps` - Saves a scraped app to the database
- `DELETE /api/apps` - Clears all saved apps

### Build System
- **Development**: Vite dev server with HMR, proxied through Express
- **Production**: esbuild bundles server code, Vite builds client to `dist/public`
- **Shared Code**: `shared/` directory contains schemas and route definitions used by both frontend and backend

## External Dependencies

### Database
- **Neon PostgreSQL**: Serverless Postgres database (requires `DATABASE_URL` environment variable)
- **Drizzle Kit**: Database migrations via `npm run db:push`

### Third-Party Libraries
- **@neondatabase/serverless**: PostgreSQL driver for serverless environments
- **Cheerio**: HTML parsing for scraping Google Play Store pages
- **Radix UI**: Accessible UI primitives (dialogs, tooltips, forms, etc.)
- **TanStack Query**: Data fetching and caching
- **Framer Motion**: Animation library

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Development tooling (dev only)
- **@replit/vite-plugin-dev-banner**: Development banner (dev only)