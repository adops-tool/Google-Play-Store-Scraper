import { db } from "./db";
import { scrapedApps, type InsertScrapedApp, type ScrapedApp } from "@shared/schema";

export interface IStorage {
  getApps(): Promise<ScrapedApp[]>;
  createApp(app: InsertScrapedApp): Promise<ScrapedApp>;
  clearApps(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getApps(): Promise<ScrapedApp[]> {
    return await db.select().from(scrapedApps).orderBy(scrapedApps.id);
  }

  async createApp(app: InsertScrapedApp): Promise<ScrapedApp> {
    const [newApp] = await db.insert(scrapedApps).values(app).returning();
    return newApp;
  }

  async clearApps(): Promise<void> {
    await db.delete(scrapedApps);
  }
}

export const storage = new DatabaseStorage();
